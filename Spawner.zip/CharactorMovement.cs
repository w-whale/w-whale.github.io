using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharactorMovement : MonoBehaviour
{
    [Header("--移动--")]
    [SerializeField]
    private float speed = 5f;           // 移动速度
    [SerializeField]
    private float turnSpeed = 0.05f;    // 旋转速度

    [Header("--车道设定--")]
    [SerializeField]
    private float distance = 5f;        // 距离
    [SerializeField]
    private int direction = 1;          // 方向 (0 = 左, 1 = 中, 2 = 右)

    [Header("--跳跃设定--")]
    [SerializeField]
    private float gravity = 12f;        // 重力
    [SerializeField]
    private float jumpForce = 10f;      // 跳起来的推力

    [Header("--翻滚设定--")]
    [SerializeField]
    private float rollingTime = 1f;                                     // 翻转时间
    [SerializeField]
    private float targetCapsuleHeight = 0.5f;                           // 碰撞体高度
    [SerializeField]
    private Vector3 targetCapsuleCenter = new Vector3(0, 3f, 0);        // 碰撞体位置

    [Header("--地上判定--")]
    [SerializeField]
    private float groundCheckRadius = 0.25f;                            // 圈圈
    [SerializeField]
    private float groundCheckOffset = -0.5f;                            // 碰撞体偏移量
    [SerializeField]
    private float groundCheckDistance = 0.4f;                           // 距离
    [SerializeField]
    private LayerMask groundMask;                                       // 屏蔽


    // 确保角色一直接触到地板
    private float verticalVelocity = -0.1f;                             // 垂直重力
    private CharacterController characterController;                    // 脚本控制
    private Animator animator;
    private float capsuleHeight;                                        // 碰撞体高度
    private Vector3 capsuleCenter;                                      // 碰撞体xyz
    private Vector3 groundNormal = Vector3.up;                          // 新增新的 Vector3
    private bool isRolling;                                             // 设定布尔值确认是否翻滚
    private float rollElapsedTime;                                      // 翻滚定时器

    private void Start()
    {
        // 抓取组件
        characterController = GetComponent<CharacterController>();
        // 抓取碰撞体高度
        capsuleHeight = characterController.height;
        // 抓取碰撞体 xyz
        capsuleCenter = characterController.center;
        animator = GetComponent<Animator>();
    }

    private void SetMoveDirection(bool isRight)
    {
        // ? 是 （? :）的简洁写法，用于根据条件选择不同的值进行运算。
        direction += isRight ? 1 : -1;              // True = 1 , False = -1
        // Clamp 界定范围
        direction = Mathf.Clamp(direction, 0, 2);   // (0 = 左, 1 = 中, 2 = 右)
    }

    private void SetLookDirection()
    {
        // 当移动往左或往右时，旋转角色
        Vector3 lookDirection = characterController.velocity;       // 角色速率

        if (lookDirection == Vector3.zero) return;                  // 如果为0 , return

        lookDirection.y = 0;

        // Lerp 滑顺
        transform.forward = Vector3.Lerp(transform.forward, lookDirection, turnSpeed);
    }

    private void MoveTo()
    {
        // 往前移动 只需抓取Z轴 向前动就可以
        Vector3 targetPosition = transform.position.z * Vector3.forward;

        // 往左 或 往右
        if (direction == 0) targetPosition += Vector3.left * distance;
        else if(direction == 2) targetPosition += Vector3.right * distance;

        // 计算xyz移动数值
        Vector3 movement = Vector3.zero;
        movement.x = (targetPosition - transform.position).normalized.x * speed;    // 左右移动
        movement.y = verticalVelocity;                                              // 垂直速率
        movement.z = speed;

        // 移动角色
        characterController.Move(movement * Time.deltaTime);
    }

    private void Jump()
    {
        // 如果在地板
        if (CheckGrounded())
        {
            // 按下空格键
            if (Input.GetKeyDown(KeyCode.Space)) verticalVelocity = jumpForce;
        }
        // 设定落下时间
        else
        {
            verticalVelocity -= (gravity * Time.deltaTime);
        }
        animator.SetBool("IsGround", CheckGrounded());
    }

    // 确定角色是否在地上
    private bool CheckGrounded()
    {
        // 寻找开始位置 (射线起点)
        Vector3 start = transform.position + Vector3.up * groundCheckOffset;
        // 执行圆形射线 start, radius, direction, hit info, distance, layermask (依照官方公式)
        if(Physics.SphereCast(start, groundCheckRadius, Vector3.down, out RaycastHit hit, groundCheckDistance, groundMask))
        {
            groundNormal = hit.normal;
            return true;
        }
        groundNormal = Vector3.up;
        return false;

    }

    private void Roll()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            if (isRolling || !CheckGrounded()) return;
            rollElapsedTime = 0f;
            isRolling = true;
            // 如果正在滚动 缩小碰撞体
            characterController.height = targetCapsuleHeight;
            characterController.center = targetCapsuleCenter;
        }
        // 计时秒数
        rollElapsedTime += Time.deltaTime;

        // 重置所有值 (秒数到，回归正常大小)
        if(rollElapsedTime>= rollingTime && isRolling)
        {
            characterController.height = targetCapsuleHeight;
            characterController.center = targetCapsuleCenter;
            rollElapsedTime = 0f;
            isRolling = false;
        }
        animator.SetBool("IsRolling", isRolling);
    }

    private void Update()
    {
        // 用指定移动按键设定方向
        if (Input.GetKeyDown(KeyCode.A)) SetMoveDirection(false);
        if (Input.GetKeyDown(KeyCode.D)) SetMoveDirection(true);

        MoveTo();
        SetLookDirection();
        Jump();
        Roll();
    }

    // Debug功能
    private void OnDrawGizmosSelected()
    {
        // 设定 gizmos 颜色
        Gizmos.color = Color.red;
        if (CheckGrounded()) Gizmos.color = Color.green;

        // 寻找 开始/结束 位置的圆形射线
        Vector3 start = transform.position + Vector3.up * groundCheckOffset;
        Vector3 end = start + Vector3.down * groundCheckDistance;

        // 画圆形导引线
        Gizmos.DrawWireSphere(start, groundCheckRadius);
        Gizmos.DrawWireSphere(end, groundCheckRadius);
    }

}
