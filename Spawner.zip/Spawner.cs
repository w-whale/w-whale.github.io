using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [Header("关卡"), SerializeField]
    private GameObject[] levels;
    [Header("关卡停留时间"), SerializeField]
    private float stayTime = 15f;

    // 是否已经生成关卡
    private bool isSpawn;
    // 经过的时间
    private float elapsedTime;

    public void SpawnLevel()
    {
        if (levels == null) return;

        int randomIndex = Random.Range(0, levels.Length);

        GameObject level = Instantiate(levels[randomIndex], transform.position, transform.rotation) as GameObject;

        // 移除生成对象时名称赋予 "Clone"
        level.name = level.name.Replace("(Clone)", "").Trim();

        isSpawn = true;
    }

    private void Update()
    {
        if (!isSpawn) return;

        // 摧毁关卡
        elapsedTime += Time.deltaTime;
        print("elapsed time: " + elapsedTime);

        // 如果 elapsedTime 大于等于 设定好的时间
        if (elapsedTime >= stayTime)
        {
            elapsedTime = 0;
            isSpawn = false;
            Destroy(transform.parent.parent.gameObject);
        }
    }
}
